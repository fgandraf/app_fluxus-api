﻿
namespace FluxusApi.Repositories

{
    public static class ConnectionString
    {
        public static string Get()
            => "SERVER=localhost;DATABASE=fluxus;UID=root;PWD=1q2w3e4r@#$;";
    }
}
